package com.rashed.admission15;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;

public class Adhstu extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_adhstu);
		Thread tr = new Thread(){
			       public void run(){
			    	    try {
							sleep(2000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			    	    finally{
			    	    	startActivity(new Intent(Adhstu.this,result.class));
			    	    }
			    	    
			       }
			
			
		};
        tr.start(); 
}
	
	
}
