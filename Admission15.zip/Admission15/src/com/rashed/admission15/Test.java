package com.rashed.admission15;

public class Test {
	
	
	
	String  info(long y)
	{
		
		//1
		if((y>=100001 && y<=100030)||(y>=106001 && y<=106030)||(y>=206001 && y<=206030)||(y>=600001 && y<=600030)||(y>=200001 && y<=200030)||(y>=350001 && y<=350030)||(y>=300001 && y<=300030)||(y>=400001 && y<=400030)||(y>=500001 && y<=500030))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: Ground Floor\nRoom: Soil Science Lab-1";			
		}
		//2
		else if((y>=100031 && y<=100065)||(y>=200031 && y<=200065)||(y>=106031 && y<=106065)||(y>=206031 && y<=206065)||(y>=300031 && y<=300065)||(y>=350031 && y<=350065)||(y>=400031 && y<=400065)||(y>=500031 && y<=500065)||(y>=600031 && y<=600065))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: Ground Floor\nRoom: Horticulture Lab-1";			
		}
		//3
		else if((y>=100066 && y<=100095)||(y>=200066 && y<=200095)||(y>=106066 && y<=106095)||(y>=206066 && y<=206095)||(y>=300066 && y<=300095)||(y>=350066 && y<=350095)||(y>=400066 && y<=400095)||(y>=500066 && y<=500095)||(y>=600066 && y<=600095))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: Ground Floor\nRoom: Horticulture Lab-2";			
		}
		//4
		else if((y>=100096 && y<=100127)||(y>=200096 && y<=200127)||(y>=106096 && y<=106127)||(y>=206096 && y<=206127)||(y>=300096 && y<=300127)||(y>=350096 && y<=350127)||(y>=400096 && y<=400127)||(y>=500096 && y<=500127)||(y>=600096 && y<=600127))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: Ground Floor\nRoom: Agronomy Lab-1";			
		}
		//5
		else if((y>=100128 && y<=100229)||(y>=200128 && y<=200229)||(y>=106128 && y<=106229)||(y>=206128 && y<=206229)||(y>=300128 && y<=300229)||(y>=350128 && y<=350229)||(y>=400128 && y<=400229)||(y>=500128 && y<=500229)||(y>=600128 && y<=600229))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: Ground Floor\nRoom: Class room 103";			
		}
		//6
		else if((y>=100230 && y<=100264)||(y>=200230 && y<=200264)||(y>=106230 && y<=106264)||(y>=206230 && y<=206264)||(y>=300230 && y<=300264)||(y>=350230 && y<=350264)||(y>=400230 && y<=400264)||(y>=500230 && y<=500264)||(y>=600230 && y<=600264))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: Ground Floor\nRoom: Agri Chemeistry Lab-1";			
		}
		//7
		else if((y>=100265 && y<=100289)||(y>=200265 && y<=200289)||(y>=106265 && y<=106289)||(y>=206265 && y<=206289)||(y>=300265 && y<=300289)||(y>=350265 && y<=350289)||(y>=400265 && y<=400289)||(y>=500265 && y<=500289)||(y>=600265 && y<=600289))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 1st Floor\nRoom: Soil Science Lab-2";			
		}
		//8
		else if((y>=100290 && y<=100319)||(y>=200290 && y<=200319)||(y>=106290 && y<=106319)||(y>=206290 && y<=206319)||(y>=300290 && y<=300319)||(y>=350290 && y<=350319)||(y>=400290 && y<=400319)||(y>=500290 && y<=500319)||(y>=600290 && y<=600319))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 1st Floor\nRoom: Agri Chemistry Lab-2";			
		}
		//9
		else if((y>=100320 && y<=100444)||(y>=200320 && y<=200444)||(y>=106320 && y<=106444)||(y>=206320 && y<=206444)||(y>=300320 && y<=300444)||(y>=350320 && y<=350444)||(y>=400320 && y<=400444)||(y>=500320 && y<=500444)||(y>=600320 && y<=600444))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 1st Floor\nRoom: Class room 201";			
		}
		//10
		else if((y>=100445 && y<=100594)||(y>=200445 && y<=200594)||(y>=106445 && y<=106594)||(y>=206445 && y<=206594)||(y>=300445 && y<=300594)||(y>=350445 && y<=350594)||(y>=400445 && y<=400594)||(y>=500445 && y<=500594)||(y>=600445 && y<=600594))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 1st Floor\nRoom: Class room 202";			
		}
		//11
		else if((y>=100595 && y<=100629)||(y>=200595 && y<=200629)||(y>=106595 && y<=106629)||(y>=206595 && y<=206629)||(y>=300595 && y<=300629)||(y>=350595 && y<=350629)||(y>=400595 && y<=400629)||(y>=500595 && y<=500629)||(y>=600595 && y<=600629))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 1st Floor\nRoom: Plant Pathology Lab-1";			
		}
		//12
		else if((y>=100630 && y<=100649)||(y>=200630 && y<=200649)||(y>=106630 && y<=106649)||(y>=206630 && y<=206649)||(y>=300630 && y<=300649)||(y>=350630 && y<=350649)||(y>=400630 && y<=400649)||(y>=500630 && y<=500649)||(y>=600630 && y<=600649))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 1st Floor\nRoom: Plant Pathology Lab-2";			
		}
		//13
		else if((y>=100650 && y<=100679)||(y>=200650 && y<=200679)||(y>=106650 && y<=106679)||(y>=206650 && y<=206679)||(y>=300650 && y<=300679)||(y>=350650 && y<=350679)||(y>=400650 && y<=400679)||(y>=500650 && y<=500679)||(y>=600650 && y<=600679))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 1st Floor\nRoom: Entomology Lab";			
		}
		//14
		else if((y>=100680 && y<=100699)||(y>=200680 && y<=200699)||(y>=106680 && y<=106699)||(y>=206680 && y<=206699)||(y>=300680 && y<=300699)||(y>=350680 && y<=350699)||(y>=400680 && y<=400699)||(y>=500680 && y<=500699)||(y>=600680 && y<=600699))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 1st Floor\nRoom: Agri. Dean Office Conf. Room";			
		}
		//15
		else if((y>=100700 && y<=100729)||(y>=200700 && y<=200729)||(y>=106700 && y<=106729)||(y>=206700 && y<=206729)||(y>=300700 && y<=300729)||(y>=350700 && y<=350729)||(y>=400700 && y<=400729)||(y>=500700 && y<=500729)||(y>=600700 && y<=600729))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 2nd Floor\nRoom: Crop Physiology Lab.";			
		}
		//16
		else if((y>=100730 && y<=100764)||(y>=200730 && y<=200764)||(y>=106730 && y<=106764)||(y>=206730 && y<=206764)||(y>=300730 && y<=300764)||(y>=350730 && y<=350764)||(y>=400730 && y<=400764)||(y>=500730 && y<=500764)||(y>=600730 && y<=600764))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 2nd Floor\nRoom: Genetics & Plant Breeding Lab";			
		}
		//17
		else if((y>=100765 && y<=100866)||(y>=200765 && y<=200866)||(y>=106765 && y<=106866)||(y>=206765 && y<=206866)||(y>=300765 && y<=300866)||(y>=350765 && y<=350866)||(y>=400765 && y<=400866)||(y>=500765 && y<=500866)||(y>=600765 && y<=600866))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 2nd Floor\nRoom: Class Room-301";			
		}
		//18
		else if((y>=100867 && y<=100991)||(y>=200867 && y<=200991)||(y>=106867 && y<=106991)||(y>=206867 && y<=206991)||(y>=300867 && y<=300991)||(y>=350867 && y<=350991)||(y>=400867 && y<=400991)||(y>=500867 && y<=500991)||(y>=600867 && y<=600991))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 2nd Floor\nRoom: Class Room-302";			
		}
		//19
		else if((y>=100992 && y<=101051)||(y>=200992 && y<=201051)||(y>=106992 && y<=107051)||(y>=206992 && y<=207051)||(y>=300992 && y<=301051)||(y>=350992 && y<=351051)||(y>=400992 && y<=401051)||(y>=500992 && y<=501051)||(y>=600992 && y<=601051))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 2nd Floor\nRoom: Agril. Extension Lab";			
		}
		//20
		else if((y>=101052 && y<=101091)||(y>=201052 && y<=201091)||(y>=107052 && y<=107091)||(y>=207052 && y<=207091)||(y>=301052 && y<=301091)||(y>=351052 && y<=351091)||(y>=401052 && y<=401091)||(y>=501052 && y<=501091)||(y>=601052 && y<=601091))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 2nd Floor\nRoom: Agroforestry Lab (Old Staistics Lab)";			
		}
		//21
		else if((y>=101092 && y<=101239)||(y>=201092 && y<=201239)||(y>=107092 && y<=107239)||(y>=207092 && y<=207239)||(y>=301092 && y<=301239)||(y>=351092 && y<=351239)||(y>=401092 && y<=401239)||(y>=501092 && y<=501239)||(y>=601092 && y<=601239))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-1 \nLoation: 3rd Floor\nRoom: Class Room-401";			
		}
		//End of Aca-1
		
		
		//Academic building-2
		//1
		else if((y>=101240 && y<=101324)||(y>=201240 && y<=201324)||(y>=107240 && y<=107324)||(y>=207240 && y<=207324)||(y>=301240 && y<=301324)||(y>=351240 && y<=351324)||(y>=401240 && y<=401324)||(y>=501240 && y<=501324)||(y>=601240 && y<=601324))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-2 \nLoation: Ground Floor\nRoom: Class Room-101";			
		}
		//2
		else if((y>=101325 && y<=101384)||(y>=201325 && y<=201384)||(y>=107325 && y<=107384)||(y>=207325 && y<=207384)||(y>=301325 && y<=301384)||(y>=351325 && y<=351384)||(y>=401325 && y<=401384)||(y>=501325 && y<=501384)||(y>=601325 && y<=601384))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-2 \nLoation: Ground Floor\nRoom: Class Room-102";			
		}
		//3
		else if((y>=101385 && y<=101452)||(y>=201385 && y<=201452)||(y>=107385 && y<=107452)||(y>=207385 && y<=207452)||(y>=301385 && y<=301452)||(y>=351385 && y<=351452)||(y>=401385 && y<=401452)||(y>=501385 && y<=501452)||(y>=601385 && y<=601452))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-2 \nLoation: Ground Floor\nRoom: Class Room-105";			
		}
		//4
		else if((y>=101453 && y<=101487)||(y>=201453 && y<=201487)||(y>=107453 && y<=107487)||(y>=207453 && y<=207487)||(y>=301453 && y<=301487)||(y>=351453 && y<=351487)||(y>=401453 && y<=401487)||(y>=501453 && y<=501487)||(y>=601453 && y<=601487))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-2 \nLoation: Ground Floor\nRoom: Food Process lab";			
		}
		//5
		else if((y>=101488 && y<=101577)||(y>=201488 && y<=201577)||(y>=107488 && y<=107577)||(y>=207488 && y<=207577)||(y>=301488 && y<=301577)||(y>=351488 && y<=351577)||(y>=401488 && y<=401577)||(y>=501488 && y<=501577)||(y>=601488 && y<=601577))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-2 \nLoation: Ground Floor\nRoom: Food Process Drawing lab";			
		}
		//6
		else if((y>=101578 && y<=101717)||(y>=201578 && y<=201717)||(y>=107578 && y<=107717)||(y>=207578 && y<=207717)||(y>=301578 && y<=301717)||(y>=351578 && y<=351717)||(y>=401578 && y<=401717)||(y>=501578 && y<=501717)||(y>=601578 && y<=601717))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-2 \nLoation: East 1st Floor\nRoom: Class Room-201";			
		}
		//7
		else if((y>=101718 && y<=101737)||(y>=201718 && y<=201737)||(y>=107718 && y<=107737)||(y>=207718 && y<=207737)||(y>=301718 && y<=301737)||(y>=351718 && y<=351737)||(y>=401718 && y<=401737)||(y>=501718 && y<=501737)||(y>=601718 && y<=601737))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-2 \nLoation: East 1st Floor\nRoom: Class Room-203";			
		}
		//8
		else if((y>=101738 && y<=101762)||(y>=201738 && y<=201762)||(y>=107738 && y<=107762)||(y>=207738 && y<=207762)||(y>=301738 && y<=301762)||(y>=351738 && y<=351762)||(y>=401738 && y<=401762)||(y>=501738 && y<=501762)||(y>=601738 && y<=601762))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-2 \nLoation: West 1st Floor\nRoom: Food Eng. Lab";			
		}
		//9
		else if((y>=101763 && y<=101782)||(y>=201763 && y<=201782)||(y>=107763 && y<=107782)||(y>=207763 && y<=207782)||(y>=301763 && y<=301782)||(y>=351763 && y<=351782)||(y>=401763 && y<=401782)||(y>=501763 && y<=501782)||(y>=601763 && y<=601782))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-2 \nLoation: West 1st Floor\nRoom: Computer lab";			
		}
		//End of Academic-2
		
		
		//Academic-3
		//1
		else if((y>=101783 && y<=101814)||(y>=201783 && y<=201814)||(y>=107783 && y<=107814)||(y>=207783 && y<=207814)||(y>=301783 && y<=301814)||(y>=351783 && y<=351814)||(y>=401783 && y<=401814)||(y>=501783 && y<=501814)||(y>=601783 && y<=601814))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: Ground Floor\nRoom: Anatomy Lab.";			
		}
		//2
		else if((y>=101815 && y<=101834)||(y>=201815 && y<=201834)||(y>=107815 && y<=107834)||(y>=207815 && y<=207834)||(y>=301815 && y<=301834)||(y>=351815 && y<=351834)||(y>=401815 && y<=401834)||(y>=501815 && y<=501834)||(y>=601815 && y<=601834))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: Ground Floor\nRoom: Histology Lab.";			
		}
		//3
		else if((y>=101835 && y<=101854)||(y>=201835 && y<=201854)||(y>=107835 && y<=107854)||(y>=207835 && y<=207854)||(y>=301835 && y<=301854)||(y>=351835 && y<=351854)||(y>=401835 && y<=401854)||(y>=501835 && y<=501854)||(y>=601835 && y<=601854))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: Ground Floor\nRoom: Medicine lab.";			
		}
		//4
		else if((y>=101855 && y<=101874)||(y>=201855 && y<=201874)||(y>=107855 && y<=107874)||(y>=207855 && y<=207874)||(y>=301855 && y<=301874)||(y>=351855 && y<=351874)||(y>=401855 && y<=401874)||(y>=501855 && y<=501874)||(y>=601855 && y<=601874))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: Ground Floor\nRoom: Genetics and Breeding lab.";			
		}
		//5
		else if((y>=101875 && y<=101911)||(y>=201875 && y<=201911)||(y>=107875 && y<=107911)||(y>=207875 && y<=207911)||(y>=301875 && y<=301911)||(y>=351875 && y<=351911)||(y>=401875 && y<=401911)||(y>=501875 && y<=501911)||(y>=601875 && y<=601911))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: Ground Floor\nRoom: Clinical Pathology Lab.";			
		}
		//6
		else if((y>=101912 && y<=101939)||(y>=201912 && y<=201939)||(y>=107912 && y<=107939)||(y>=207912 && y<=207939)||(y>=301912 && y<=301939)||(y>=351912 && y<=351939)||(y>=401912 && y<=401939)||(y>=501912 && y<=501939)||(y>=601912 && y<=601939))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: Ground Floor\nRoom: Virology lab";			
		}
		//7
		else if((y>=101940 && y<=101999)||(y>=201940 && y<=201999)||(y>=107940 && y<=107999)||(y>=207940 && y<=207999)||(y>=301940 && y<=301999)||(y>=351940 && y<=351999)||(y>=401940 && y<=401999)||(y>=501940 && y<=501999)||(y>=601940 && y<=601999))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: 1st Floor\nRoom: Class room-1";			
		}
		//8
		else if((y>=102000 && y<=102034)||(y>=202000 && y<=202034)||(y>=108000 && y<=108034)||(y>=208000 && y<=208034)||(y>=302000 && y<=302034)||(y>=352000 && y<=352034)||(y>=402000 && y<=402034)||(y>=502000 && y<=502034)||(y>=602000 && y<=602034))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: 1st Floor\nRoom: Pathology Lab.";			
		}
		//9
		else if((y>=102035 && y<=102059)||(y>=202035 && y<=202059)||(y>=108035 && y<=108059)||(y>=208035 && y<=208059)||(y>=302035 && y<=302059)||(y>=352035 && y<=352059)||(y>=402035 && y<=402059)||(y>=502035 && y<=502059)||(y>=602035 && y<=602059))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: 1st Floor\nRoom: Microbiology lab";			
		}
		//10
		else if((y>=102060 && y<=102149)||(y>=202060 && y<=202149)||(y>=108060 && y<=108149)||(y>=208060 && y<=208149)||(y>=302060 && y<=302149)||(y>=352060 && y<=352149)||(y>=402060 && y<=402149)||(y>=502060 && y<=502149)||(y>=602060 && y<=602149))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: 2nd Floor\nRoom: Class Room � 2";			
		}
		//11
		else if((y>=102150 && y<=102229)||(y>=202150 && y<=202229)||(y>=108150 && y<=108229)||(y>=208150 && y<=208229)||(y>=302150 && y<=302229)||(y>=352150 && y<=352229)||(y>=402150 && y<=402229)||(y>=502150 && y<=502229)||(y>=602150 && y<=602229))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: 2nd Floor\nRoom: Class Room � 3";			
		}
		//12
		else if((y>=102230 && y<=102309)||(y>=202230 && y<=202309)||(y>=108230 && y<=108309)||(y>=208230 && y<=208309)||(y>=302230 && y<=302309)||(y>=352230 && y<=352309)||(y>=402230 && y<=402309)||(y>=502230 && y<=502309)||(y>=602230 && y<=602309))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: 2nd Floor\nRoom: Class Room � 4";			
		}
		//13
		else if((y>=102310 && y<=102389)||(y>=202310 && y<=202389)||(y>=108310 && y<=108389)||(y>=208310 && y<=208389)||(y>=302310 && y<=302389)||(y>=352310 && y<=352389)||(y>=402310 && y<=402389)||(y>=502310 && y<=502389)||(y>=602310 && y<=602389))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: 2nd Floor\nRoom: Class Room � 5";			
		}
		//14
		else if((y>=102390 && y<=102411)||(y>=202390 && y<=202411)||(y>=108390 && y<=108411)||(y>=208390 && y<=208411)||(y>=302390 && y<=302411)||(y>=352390 && y<=352411)||(y>=402390 && y<=402411)||(y>=502390 && y<=502411)||(y>=602390 && y<=602411))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: 3rd Floor\nRoom: Parasitology Lab.";			
		}
		//15
		else if((y>=102412 && y<=102433)||(y>=202412 && y<=202433)||(y>=108412 && y<=108433)||(y>=208412 && y<=208433)||(y>=302412 && y<=302433)||(y>=352412 && y<=352433)||(y>=402412 && y<=402433)||(y>=502412 && y<=502433)||(y>=602412 && y<=602433))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: 3rd Floor\nRoom: Physiology Lab.";			
		}
		//16
		else if((y>=102434 && y<=102453)||(y>=202434 && y<=202453)||(y>=108434 && y<=108453)||(y>=208434 && y<=208453)||(y>=302434 && y<=302453)||(y>=352434 && y<=352453)||(y>=402434 && y<=402453)||(y>=502434 && y<=502453)||(y>=602434 && y<=602453))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: 3rd Floor\nRoom: Pharmacology lab";			
		}
		//17
		else if((y>=102454 && y<=102477)||(y>=202454 && y<=202477)||(y>=108454 && y<=108477)||(y>=208454 && y<=208477)||(y>=302454 && y<=302477)||(y>=352454 && y<=352477)||(y>=402454 && y<=402477)||(y>=502454 && y<=502477)||(y>=602454 && y<=602477))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: 3rd Floor\nRoom: General Animal Science Lab.";			
		}
		//18
		else if((y>=102478 && y<=102507)||(y>=202478 && y<=202507)||(y>=108478 && y<=108507)||(y>=208478 && y<=208507)||(y>=302478 && y<=302507)||(y>=352478 && y<=352507)||(y>=402478 && y<=402507)||(y>=502478 && y<=502507)||(y>=602478 && y<=602507))
		{			
		  return  "Roll No:"+y+"\nVenue : Academic Building-3 \nLoation: 3rd Floor\nRoom: Dairy & Poultry Science Lab.";			
		}
		//End of Academic-3
		
		//Library Building
		//1
		else if((y>=102508 && y<=102527)||(y>=202508 && y<=202527)||(y>=108508 && y<=108527)||(y>=208508 && y<=208527)||(y>=302508 && y<=302527)||(y>=352508 && y<=352527)||(y>=402508 && y<=402527)||(y>=502508 && y<=502527)||(y>=602508 && y<=602527))
		{			
		  return  "Roll No:"+y+"\nVenue : Library Building \nLoation: Ground Floor\nRoom: Internet room";			
		}
		//2
		else if((y>=102528 && y<=102587)||(y>=202528 && y<=202587)||(y>=108528 && y<=108587)||(y>=208528 && y<=208587)||(y>=302528 && y<=302587)||(y>=352528 && y<=352587)||(y>=402528 && y<=402587)||(y>=502528 && y<=502587)||(y>=602528 && y<=602587))
		{			
		  return  "Roll No:"+y+"\nVenue : Library Building \nLoation: 1st Floor\nRoom: Reading room";			
		}
		//3		
		else if((y>=102588 && y<=102627)||(y>=202588 && y<=202627)||(y>=108588 && y<=108627)||(y>=208588 && y<=208627)||(y>=302588 && y<=302627)||(y>=352588 && y<=352627)||(y>=402588 && y<=402627)||(y>=502588 && y<=502627)||(y>=602588 && y<=602627))
		{			
		  return  "Roll No:"+y+"\nVenue : Library Building \nLoation: 2nd Floor\nRoom: M.S. Reading room";			
		}
		//End of Library
		
		//Field Labs
		//1
		else if((y>=102628 && y<=102677)||(y>=202628 && y<=202677)||(y>=108628 && y<=108677)||(y>=208628 && y<=208677)||(y>=302628 && y<=302677)||(y>=352628 && y<=352677)||(y>=402628 && y<=402677)||(y>=502628 && y<=502677)||(y>=602628 && y<=602677))
		{			
		  return  "Roll No:"+y+"\nVenue : Field Labs \nLoation: Behind Library\nRoom: AIE-1 (Farm Mechanics Field lab)";			
		}
		//2
		else if((y>=102678 && y<=102729)||(y>=202678 && y<=202729)||(y>=108678 && y<=108729)||(y>=208678 && y<=208729)||(y>=302678 && y<=302729)||(y>=352678 && y<=352729)||(y>=402678 && y<=402729)||(y>=502678 && y<=502729)||(y>=602678 && y<=602729))
		{			
		  return  "Roll No:"+y+"\nVenue : Field Labs \nLoation: Behind Library\nRoom: AIE (Hydraulics Field lab)";			
		}
		//3
		else if((y>=102730 && y<=102779)||(y>=202730 && y<=202779)||(y>=108730 && y<=108779)||(y>=208730 && y<=208779)||(y>=302730 && y<=302779)||(y>=352730 && y<=352779)||(y>=402730 && y<=402779)||(y>=502730 && y<=502779)||(y>=602730 && y<=602779))
		{			
		  return  "Roll No:"+y+"\nVenue : Field Labs \nLoation: Behind Library\nRoom: AIE (Horticulture Field lab)";			
		}
		//4
		else if((y>=102780 && y<=102809)||(y>=202780 && y<=202809)||(y>=108780 && y<=108809)||(y>=208780 && y<=208809)||(y>=302780 && y<=302809)||(y>=352780 && y<=352809)||(y>=402780 && y<=402809)||(y>=502780 && y<=502809)||(y>=602780 && y<=602809))
		{			
		  return  "Roll No:"+y+"\nVenue : Field Labs \nLoation: Behind Library\nRoom: Agronomy Field Lab";			
		}
		//End of Field lab
		
		//Dr. Wazed Building (Ground Floor)
		//1
		else if((y>=102810 && y<=102869)||(y>=202810 && y<=202869)||(y>=108810 && y<=108869)||(y>=208810 && y<=208869)||(y>=302810 && y<=302869)||(y>=352810 && y<=352869)||(y>=402810 && y<=402869)||(y>=502810 && y<=502869)||(y>=602810 && y<=602869))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: Ground Floor\nRoom: Room 101";			
		}
		//2
		else if((y>=102870 && y<=102929)||(y>=202870 && y<=202929)||(y>=108870 && y<=108929)||(y>=208870 && y<=208929)||(y>=302870 && y<=302929)||(y>=352870 && y<=352929)||(y>=402870 && y<=402929)||(y>=502870 && y<=502929)||(y>=602870 && y<=602929))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: Ground Floor\nRoom: Room 102";			
		}
		//3
		else if((y>=102930 && y<=103029)||(y>=202930 && y<=203029)||(y>=108930 && y<=109029)||(y>=208930 && y<=209029)||(y>=302930 && y<=303029)||(y>=352930 && y<=353029)||(y>=402930 && y<=403029)||(y>=502930 && y<=503029)||(y>=602930 && y<=603029))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: Ground Floor\nRoom: Room 103";			
		}
		//4
		else if((y>=103030 && y<=103139)||(y>=203030 && y<=203139)||(y>=109030 && y<=109139)||(y>=209030 && y<=209139)||(y>=303030 && y<=303139)||(y>=353030 && y<=353139)||(y>=403030 && y<=403139)||(y>=503030 && y<=503139)||(y>=603030 && y<=603139))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: Ground Floor\nRoom: Room 104";			
		}
		//5
		else if((y>=103140 && y<=103249)||(y>=203140 && y<=203249)||(y>=109140 && y<=109249)||(y>=209140 && y<=209249)||(y>=303140 && y<=303249)||(y>=353140 && y<=353249)||(y>=403140 && y<=403249)||(y>=503140 && y<=503249)||(y>=603140 && y<=603249))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: Ground Floor\nRoom: Room 105";			
		}
		//6
		else if((y>=103250 && y<=103299)||(y>=203250 && y<=203299)||(y>=109250 && y<=109299)||(y>=209250 && y<=209299)||(y>=303250 && y<=303299)||(y>=353250 && y<=353299)||(y>=403250 && y<=403299)||(y>=503250 && y<=503299)||(y>=603250 && y<=603299))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: Ground Floor\nRoom: Room 110";			
		}
		//7
		else if((y>=103300 && y<=103349)||(y>=203300 && y<=203349)||(y>=109300 && y<=109349)||(y>=209300 && y<=209349)||(y>=303300 && y<=303349)||(y>=353300 && y<=353349)||(y>=403300 && y<=403349)||(y>=503300 && y<=503349)||(y>=603300 && y<=603349))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: Ground Floor\nRoom: Room 140";			
		}
		//8
		else if((y>=103350 && y<=103399)||(y>=203350 && y<=203399)||(y>=109350 && y<=109399)||(y>=209350 && y<=209399)||(y>=303350 && y<=303399)||(y>=353350 && y<=353399)||(y>=403350 && y<=403399)||(y>=503350 && y<=503399)||(y>=603350 && y<=603399))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: Ground Floor\nRoom: Room 141";			
		}
		//9
		else if((y>=103400 && y<=103499)||(y>=203400 && y<=203499)||(y>=109400 && y<=109499)||(y>=209400 && y<=209499)||(y>=303400 && y<=303499)||(y>=353400 && y<=353499)||(y>=403400 && y<=403499)||(y>=503400 && y<=503499)||(y>=603400 && y<=603499))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: Ground Floor\nRoom: Room 142";			
		}
		//10
		else if((y>=103500 && y<=103619)||(y>=203500 && y<=203619)||(y>=109500 && y<=109619)||(y>=209500 && y<=209619)||(y>=303500 && y<=303619)||(y>=353500 && y<=353619)||(y>=403500 && y<=403619)||(y>=503500 && y<=503619)||(y>=603500 && y<=603619))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: Ground Floor\nRoom: Room 143";			
		}
		//11
		else if((y>=103620 && y<=103729)||(y>=203620 && y<=203729)||(y>=109620 && y<=109729)||(y>=209620 && y<=209729)||(y>=303620 && y<=303729)||(y>=353620 && y<=353729)||(y>=403620 && y<=403729)||(y>=503620 && y<=503729)||(y>=603620 && y<=603729))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: Ground Floor\nRoom: Room 144";			
		}
		//12
		else if((y>=103730 && y<=103839)||(y>=203730 && y<=203839)||(y>=109730 && y<=109839)||(y>=209730 && y<=209839)||(y>=303730 && y<=303839)||(y>=353730 && y<=353839)||(y>=403730 && y<=403839)||(y>=503730 && y<=503839)||(y>=603730 && y<=603839))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: Ground Floor\nRoom: Room 145";			
		}
		//13
		else if((y>=103840 && y<=103949)||(y>=203840 && y<=203949)||(y>=109840 && y<=109949)||(y>=209840 && y<=209949)||(y>=303840 && y<=303949)||(y>=353840 && y<=353949)||(y>=403840 && y<=403949)||(y>=503840 && y<=503949)||(y>=603840 && y<=603949))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: Ground Floor\nRoom: Room 146";			
		}
		//End of wazed ground floor
		
		
		//1st floor
		//1
		else if((y>=103950 && y<=104059)||(y>=203950 && y<=204059)||(y>=109950 && y<=110059)||(y>=209950 && y<=210059)||(y>=303950 && y<=304059)||(y>=353950 && y<=354059)||(y>=403950 && y<=404059)||(y>=503950 && y<=504059)||(y>=603950 && y<=604059))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 201";			
		}
		//2
		else if((y>=104060 && y<=104159)||(y>=204060 && y<=204159)||(y>=110060 && y<=110159)||(y>=210060 && y<=210159)||(y>=304060 && y<=304159)||(y>=354060 && y<=354159)||(y>=404060 && y<=404159)||(y>=504060 && y<=504159)||(y>=604060 && y<=604159))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 201 Corridor";			
		}
		//3
		else if((y>=104160 && y<=104259)||(y>=204160 && y<=204259)||(y>=110160 && y<=110259)||(y>=210160 && y<=210259)||(y>=304160 && y<=304259)||(y>=354160 && y<=354259)||(y>=404160 && y<=404259)||(y>=504160 && y<=504259)||(y>=604160 && y<=604259))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 203";			
		}
		//4
		else if((y>=104260 && y<=104349)||(y>=204260 && y<=204349)||(y>=110260 && y<=110349)||(y>=210260 && y<=210349)||(y>=304260 && y<=304349)||(y>=354260 && y<=354349)||(y>=404260 && y<=404349)||(y>=504260 && y<=504349)||(y>=604260 && y<=604349))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 204";			
		}
		//5
		else if((y>=104350 && y<=104449)||(y>=204350 && y<=204449)||(y>=110350 && y<=110449)||(y>=210350 && y<=210449)||(y>=304350 && y<=304449)||(y>=354350 && y<=354449)||(y>=404350 && y<=404449)||(y>=504350 && y<=504449)||(y>=604350 && y<=604449))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 205";			
		}
		//6
		else if((y>=104450 && y<=104549)||(y>=204450 && y<=204549)||(y>=110450 && y<=110549)||(y>=210450 && y<=210549)||(y>=304450 && y<=304549)||(y>=354450 && y<=354549)||(y>=404450 && y<=404549)||(y>=504450 && y<=504549)||(y>=604450 && y<=604549))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 205 corridor";			
		}
		//7
		else if((y>=104550 && y<=104594)||(y>=204550 && y<=204594)||(y>=110550 && y<=110594)||(y>=210550 && y<=210594)||(y>=304550 && y<=304594)||(y>=354550 && y<=354594)||(y>=404550 && y<=404594)||(y>=504550 && y<=504594)||(y>=604550 && y<=604594))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 210";			
		}
		//8
		else if((y>=104595 && y<=104644)||(y>=204595 && y<=204644)||(y>=110595 && y<=110644)||(y>=210595 && y<=210644)||(y>=304595 && y<=304644)||(y>=354595 && y<=354644)||(y>=404595 && y<=404644)||(y>=504595 && y<=504644)||(y>=604595 && y<=604644))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 240";			
		}
		//9
		else if((y>=104645 && y<=104694)||(y>=204645 && y<=204694)||(y>=110645 && y<=110694)||(y>=210645 && y<=210694)||(y>=304645 && y<=304694)||(y>=354645 && y<=354694)||(y>=404645 && y<=404694)||(y>=504645 && y<=504694)||(y>=604645 && y<=604694))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 241";			
		}
		//10
		else if((y>=104695 && y<=104744)||(y>=204695 && y<=204744)||(y>=110695 && y<=110744)||(y>=210695 && y<=210744)||(y>=304695 && y<=304744)||(y>=354695 && y<=354744)||(y>=404695 && y<=404744)||(y>=504695 && y<=504744)||(y>=604695 && y<=604744))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 242";			
		}
		//11
		else if((y>=104745 && y<=104824)||(y>=204745 && y<=204824)||(y>=110745 && y<=110824)||(y>=210745 && y<=210824)||(y>=304745 && y<=304824)||(y>=354745 && y<=354824)||(y>=404745 && y<=404824)||(y>=504745 && y<=504824)||(y>=604745 && y<=604824))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 243";			
		}
		//12
		else if((y>=104825 && y<=104924)||(y>=204825 && y<=204924)||(y>=110825 && y<=110924)||(y>=210825 && y<=210924)||(y>=304825 && y<=304924)||(y>=354825 && y<=354924)||(y>=404825 && y<=404924)||(y>=504825 && y<=504924)||(y>=604825 && y<=604924))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 243 corridor";			
		}
		//13
		else if((y>=104925 && y<=105034)||(y>=204925 && y<=205034)||(y>=110925 && y<=111034)||(y>=210925 && y<=211034)||(y>=304925 && y<=305034)||(y>=354925 && y<=355034)||(y>=404925 && y<=405034)||(y>=504925 && y<=505034)||(y>=604925 && y<=605034))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 245 ";			
		}
		//14
		else if((y>=105035 && y<=105114)||(y>=205035 && y<=205114)||(y>=111035 && y<=111114)||(y>=211035 && y<=211114)||(y>=305035 && y<=305114)||(y>=355035 && y<=355114)||(y>=405035 && y<=405114)||(y>=505035 && y<=505114)||(y>=605035 && y<=605114))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 246";			
		}
		//15
		else if((y>=105115 && y<=105214)||(y>=205115 && y<=205214)||(y>=111115 && y<=111214)||(y>=211115 && y<=211214)||(y>=305115 && y<=305214)||(y>=355115 && y<=355214)||(y>=405115 && y<=405214)||(y>=505115 && y<=505214)||(y>=605115 && y<=605124))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 1st Floor\nRoom: Room 246 corridor";			
		}
		//End of First floor
		
		//2nd floor
		//1
		else if((y>=105215 && y<=105264)||(y>=205215 && y<=205264)||(y>=111215 && y<=111264)||(y>=211215 && y<=211264)||(y>=305215 && y<=305264)||(y>=355215 && y<=355264)||(y>=405215 && y<=405264)||(y>=505215 && y<=505264))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 2nd Floor\nRoom: Room 340";			
		}
		//2
		else if((y>=105265 && y<=105314)||(y>=205265 && y<=205314)||(y>=111265 && y<=111314)||(y>=211265 && y<=211314)||(y>=305265 && y<=305314)||(y>=355265 && y<=355314)||(y>=405265 && y<=405314)||(y>=505265 && y<=505314))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 2nd Floor\nRoom: Room 341";			
		}
		//3
		else if((y>=105315 && y<=105414)||(y>=205315 && y<=205414)||(y>=111315 && y<=111414)||(y>=211315 && y<=211414)||(y>=305315 && y<=305414)||(y>=355315 && y<=355414)||(y>=405315 && y<=405414)||(y>=505315 && y<=505414))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 2nd Floor\nRoom: Room 342";			
		}
		//4
		else if((y>=105415 && y<=105514)||(y>=205415 && y<=205514)||(y>=111415 && y<=111514)||(y>=211415 && y<=211514)||(y>=305415 && y<=305514)||(y>=355415 && y<=355514)||(y>=405415 && y<=405514)||(y>=505415 && y<=505514))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 2nd Floor\nRoom: Room 343";			
		}
		//5
		else if((y>=105515 && y<=105614)||(y>=205515 && y<=205614)||(y>=111515 && y<=111614)||(y>=211515 && y<=211614)||(y>=305515 && y<=305614)||(y>=355515 && y<=355614)||(y>=405515 && y<=405614)||(y>=505515 && y<=505614))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 2nd Floor\nRoom: Room 343 corridor";			
		}
		//6
		else if((y>=105615 && y<=105714)||(y>=205615 && y<=205714)||(y>=111615 && y<=111714)||(y>=211615 && y<=211714)||(y>=305615 && y<=305714)||(y>=355615 && y<=355714)||(y>=405615 && y<=405714)||(y>=505615 && y<=505714))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 2nd Floor\nRoom: Room 344";			
		}
		//7
		else if((y>=105715 && y<=105814)||(y>=205715 && y<=205814)||(y>=111715 && y<=111814)||(y>=211715 && y<=211814)||(y>=305715 && y<=305814)||(y>=355715 && y<=355814)||(y>=405715 && y<=405814)||(y>=505715 && y<=505814))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 2nd Floor\nRoom: Room 345";			
		}
		//8
		else if((y>=105815 && y<=105914)||(y>=205815 && y<=205914)||(y>=111815 && y<=111914)||(y>=211815 && y<=211914)||(y>=305815 && y<=305914)||(y>=355815 && y<=355914)||(y>=405815 && y<=405914)||(y>=505815 && y<=505914))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 2nd Floor\nRoom: Room 346";			
		}
		//9
		else if((y>=105915 && y<=106000)||(y>=205915 && y<=206000)||(y>=111915 && y<=112014)||(y>=211915 && y<=212014)||(y>=305915 && y<=306014)||(y>=355915 && y<=356014)||(y>=405915 && y<=406014)||(y>=505915 && y<=506014))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 2nd Floor\nRoom: Room 346";			
		}
		//End of 2nd floor
		
		//3rd floor
		//1
		else if((y>=112015 && y<=112064)||(y>=212015 && y<=212064)||(y>=306015 && y<=306064)||(y>=356015 && y<=356064)||(y>=406015 && y<=406064)||(y>=506015 && y<=506064))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 3rd Floor\nRoom: Room 440";			
		}
		//2
		else if((y>=112065 && y<=112114)||(y>=212065 && y<=122100)||(y>=306065 && y<=306114)||(y>=356065 && y<=356114)||(y>=406065 && y<=406114)||(y>=506065 && y<=506114))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 3rd Floor\nRoom: Room 441";			
		}
		//3
		else if((y>=112115 && y<=112214)||(y>=306115 && y<=306214)||(y>=356115 && y<=356199)||(y>=406115 && y<=406214)||(y>=506115 && y<=506214))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 3rd Floor\nRoom: Room 442";			
		}
		//4		
		else if((y>=112215 && y<=112299)||(y>=306215 && y<=306314)||(y>=406215 && y<=406314)||(y>=506215 && y<=506314))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 3rd Floor\nRoom: Room 443";			
		}
		//5
		else if((y>=306315 && y<=306414)||(y>=406315 && y<=406414)||(y>=506315 && y<=506414))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 3rd Floor\nRoom: Room 444";			
		}
		//6
		else if((y>=306415 && y<=306514)||(y>=406415 && y<=406514)||(y>=506415 && y<=506514))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 3rd Floor\nRoom: Room 445";			
		}
		//7
		else if((y>=306515 && y<=306614)||(y>=406415 && y<=406600)||(y>=506515 && y<=506614))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 3rd Floor\nRoom: Room 445";			
		}
		//end of 3rd floor
		
		//4th floor
		//1
		else if((y>=306615 && y<=306664)||(y>=506615 && y<=506664))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 4th Floor\nRoom: Room 540";			
		}
		//2
		else if((y>=306665 && y<=306714)||(y>=506665 && y<=506714))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 4th Floor\nRoom: Room 541";			
		}
		//3
		else if((y>=306715 && y<=306814)||(y>=506715 && y<=506814))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 4th Floor\nRoom: Room 542";			
		}
		//4
		else if((y>=306815 && y<=306914)||(y>=506815 && y<=506914))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 4th Floor\nRoom: Room 543";			
		}
		//5
		else if((y>=306915 && y<=307014)||(y>=506915 && y<=507014))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 4th Floor\nRoom: Room 544";			
		}
		//6
		else if((y>=307015 && y<=307114)||(y>=507015 && y<=507114))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 4th Floor\nRoom: Room 545";			
		}
		//7
		else if((y>=307115 && y<=307214)||(y>=507115 && y<=507214))
		{			
		  return  "Roll No:"+y+"\nVenue : Dr. Wazed Building \nLoation: 4th Floor\nRoom: Room 546";			
		}
		//end of 4th
		
		//HSTU School
		//1
		else if((y>=307215 && y<=307248)||(y>=507215 && y<=507248))
		{			
		  return  "Roll No:"+y+"\nVenue : HSTU School \nLoation: Ground Floor\nRoom: Class Room - 101";			
		}
		//2
		else if((y>=307249 && y<=307280)||(y>=507249 && y<=507300))
		{			
		  return  "Roll No:"+y+"\nVenue : HSTU School \nLoation: Ground Floor\nRoom: Class Room - 102(A)";			
		}
		//3
		else if(y>=307281 && y<=307318)
		{			
		  return  "Roll No:"+y+"\nVenue : HSTU School \nLoation: Ground Floor\nRoom: Class Room - 102(B)";			
		}
		//4
		else if(y>=307319 && y<=307363)
		{			
		  return  "Roll No:"+y+"\nVenue : HSTU School \nLoation: Ground Floor\nRoom: Class Room - 104";			
		}
		//5
		else if(y>=307364 && y<=307400)
		{			
		  return  "Roll No:"+y+"\nVenue : HSTU School \nLoation: Ground Floor\nRoom: Class Room - 105";			
		}
		//end of school
		
		
		
		
		
		
		
		
		
		
		
		else if(y==0)
		return "Enter Roll Number";
		
		else
		return null;
		
	}
	
	String time(long x)
	{
		
		if((x>=100001 && x<=106000)||(x>=300001 && x<=307400)||(x>=400001 && x<=406600)||(x>=600001 && x<=605124))
		{			
		  return  "Time:9.30 am";			
		}
		else if(x>=200001 && x<=206000)
		{
		  return  "Time:12.00 pm";	
		}
		else if((x>=106001 && x<=122299)||(x>=206001 && x<=212100)||(x>=350001 && x<=356199)||(x>=500001 && x<=507300))
		{
		  return  "Time:3.00 pm";	
		}
		return null;
	}
	
	
	
	
}



