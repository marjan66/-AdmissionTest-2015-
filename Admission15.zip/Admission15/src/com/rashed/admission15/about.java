package com.rashed.admission15;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;



public class about extends Activity {
	WebView web;
	
	String mimeType = "text/html";
	 String encoding = "utf-8";
	 String htmlText = "<p style=text-align:center;>MD. Rashedul Islam<br/>Level-4, Semester-II<br/>C.S.E. HSTU<br/>01723595735<br/>rashed2018.cse.hstu@gmail.com<br/></p>"
	   + "<p style=text-align:center;>MD. Abu Marjan<br/>Level-4, Semester-II<br/>T.E.E. HSTU<br/>01723791394<br/>mdabumarjan@gmail.com<br/></p>";
	   
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ab);
		
		 web = (WebView)findViewById(R.id.webView1);
		 web.loadData(htmlText, mimeType, encoding);
		 web.setBackgroundColor(0);
	}

}
