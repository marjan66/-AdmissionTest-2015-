package com.rashed.admission15;





import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;



public class result extends Activity {
	
	private Button schedule,search,about;
	private EditText EditText1;
	String  message="",information="rashed",time1="";
	final Context context = this;
	long l=0,m=0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.result);
		
		schedule=(Button)findViewById(R.id.button1);
		search=(Button)findViewById(R.id.button2);
		about=(Button)findViewById(R.id.button3);
		EditText1= (EditText)findViewById(R.id.editText1);
		
		final Test test1= new Test();
		
		schedule.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(result.this,Schedule.class));

				
			}
		});
		
		about.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(result.this,about.class));

				
			}
		});
		
		search.setOnClickListener(new OnClickListener() {
            
       		public void onClick(View v) {
       			l=0;m=0;
       			
       			message= EditText1.getText().toString();
       			try {
       				 l = Long.parseLong(message);
       			   information=test1.info(l);
       			   time1=test1.time(l);
       			}
       			catch(NumberFormatException nfe) {
       			   l=0;
       			 information=test1.info(l);
       			 time1=test1.time(l);
       			} 
       		   EditText1.setText("");
       		
       			AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
       		 
    			// set title
       			alertDialogBuilder.setTitle("Seat Plan");
     
    			// set dialog message
    			alertDialogBuilder
    				.setMessage(information+"\n"+time1)
    				
    				.setCancelable(false)
    			
    				.setNegativeButton("Close",new DialogInterface.OnClickListener() {
    					public void onClick(DialogInterface dialog,int id) {
    						// if this button is clicked, just close
    						// the dialog box and do nothing
    				
    						dialog.cancel();
    						
    					}
    				});
     
    				// create alert dialog
    				AlertDialog alertDialog = alertDialogBuilder.create();
     
    				// show it
    	
    				alertDialog.show();
    				
    				
       			
              
       		}});
        //end
		
	}

}
